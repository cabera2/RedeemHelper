﻿const defaultGames = [1, 2, 3].map(i => ({
    name: chrome.i18n.getMessage(`default_${i}_name`),
    url: chrome.i18n.getMessage(`default_${i}_url`)
}));

let currentGames = [];
applyI18n();
// [저장] 데이터를 브라우저에 영구 저장하는 함수
function saveToStorage() {
    chrome.storage.sync.set({ games: currentGames }, () => {
        console.log("자동 저장 완료!");
    });
}
function applyI18n(){
    document.title = chrome.i18n.getMessage("optTitle");
    document.getElementById('header').textContent = chrome.i18n.getMessage("optHeader");
    document.getElementById('nameInput').placeholder = chrome.i18n.getMessage("optGameName");
    document.getElementById('urlInput').placeholder = chrome.i18n.getMessage("optHeader");
    document.getElementById('addBtn').textContent = chrome.i18n.getMessage("optAdd");
    document.getElementById('guide').innerHTML = chrome.i18n.getMessage("optGuide");
    document.getElementById('resetBtn').textContent = chrome.i18n.getMessage("optReset");
}

// [로드] 페이지가 열릴 때 저장된 데이터를 가져오는 로직
chrome.storage.sync.get(["games"], (result) => {
    if (result.games && result.games.length > 0) {
        currentGames = result.games;
    } else {
        currentGames = [...defaultGames]; // 데이터가 없으면 기본값 사용
    }
    renderList();
});

function renderList() {
    const itemList = document.getElementById('itemList');
    itemList.innerHTML = "";
    currentGames.forEach((game, index) => {
        const li = document.createElement('li');
        li.className = 'item';
        li.innerHTML = `
      <div class="item-info">
        <span class="game-name">${game.name}</span>
        <span class="game-url">${game.url}</span>
      </div>
      <button class="btn-delete" data-index="${index}">${chrome.i18n.getMessage("optDelete")}</button>
    `;
        itemList.appendChild(li);
    });
}

// 추가/삭제/초기화 시 saveToStorage() 호출
document.getElementById('addBtn').addEventListener('click', () => {
    const name = document.getElementById('nameInput').value.trim();
    const url = document.getElementById('urlInput').value.trim();
    if (name && url) {
        currentGames.push({ name, url });
        renderList();
        saveToStorage(); // 자동 저장
        document.getElementById('nameInput').value = "";
        document.getElementById('urlInput').value = "";
    }
});

document.getElementById('itemList').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-delete')) {
        const index = e.target.getAttribute('data-index');
        currentGames.splice(index, 1);
        renderList();
        saveToStorage(); // 자동 저장
    }
});

document.getElementById('resetBtn').addEventListener('click', () => {
    const text = chrome.i18n.getMessage("optResetWarning");
    if (confirm(text)) {
        currentGames = [...defaultGames];
        renderList();
        saveToStorage(); // 자동 저장
    }
});