﻿const defaultGames = [
    { name: "원신", url: "https://genshin.hoyoverse.com/ko/gift?code={n}" },
    { name: "붕괴:스타레일", url: "https://hsr.hoyoverse.com/gift?code={n}" },
    { name: "젠레스 존 제로", url: "https://zenless.hoyoverse.com/redemption/gift?code={n}" }
];

let currentGames = [];

// [저장] 데이터를 브라우저에 영구 저장하는 함수
function saveToStorage() {
    chrome.storage.sync.set({ games: currentGames }, () => {
        console.log("자동 저장 완료!");
    });
}

// [로드] 페이지가 열릴 때 저장된 데이터를 가져오는 로직
chrome.storage.sync.get(["games"], (result) => {
    if (result.games && result.games.length > 0) {
        currentGames = result.games;
    } else {
        currentGames = [...defaultGames]; // 데이터가 없으면 기본값 사용
    }
    renderList();
});

function renderList() {
    const itemList = document.getElementById('itemList');
    itemList.innerHTML = "";
    currentGames.forEach((game, index) => {
        const li = document.createElement('li');
        li.className = 'item';
        li.innerHTML = `
      <div class="item-info">
        <span class="game-name">${game.name}</span>
        <span class="game-url">${game.url}</span>
      </div>
      <button class="btn-delete" data-index="${index}">삭제</button>
    `;
        itemList.appendChild(li);
    });
}

// 추가/삭제/초기화 시 saveToStorage() 호출
document.getElementById('addBtn').addEventListener('click', () => {
    const name = document.getElementById('nameInput').value.trim();
    const url = document.getElementById('urlInput').value.trim();
    if (name && url) {
        currentGames.push({ name, url });
        renderList();
        saveToStorage(); // 자동 저장
        document.getElementById('nameInput').value = "";
        document.getElementById('urlInput').value = "";
    }
});

document.getElementById('itemList').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-delete')) {
        const index = e.target.getAttribute('data-index');
        currentGames.splice(index, 1);
        renderList();
        saveToStorage(); // 자동 저장
    }
});

document.getElementById('resetBtn').addEventListener('click', () => {
    if (confirm("기본값으로 초기화하시겠습니까?")) {
        currentGames = [...defaultGames];
        renderList();
        saveToStorage(); // 자동 저장
    }
});