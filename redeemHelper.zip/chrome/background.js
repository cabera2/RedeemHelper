﻿/**
 * 1. 메뉴 갱신 함수
 * 저장소에서 게임 리스트를 읽어와 우클릭 메뉴를 동적으로 생성합니다.
 */
function updateMenus() {
    // 기존 메뉴를 모두 삭제한 후 새로 생성 (중복 방지)
    chrome.contextMenus.removeAll(() => {
        chrome.storage.sync.get(["games"], (result) => {
            const games = result.games || [];

            games.forEach((game, index) => {
                chrome.contextMenus.create({
                    id: `redeem-${index}`,
                    title: `'${game.name}'(으)로 보내기`,
                    contexts: ["selection"]
                });
            });
        });
    });
}

/**
 * 2. 초기 설치/업데이트 이벤트
 */
chrome.runtime.onInstalled.addListener(() => {
    updateMenus();
});

/**
 * 3. 옵션 페이지 열기 (아이콘 클릭 시)
 * 질문하신 "옵션 페이지를 여는 부분"입니다.
 */
chrome.action.onClicked.addListener((tab) => {
    chrome.runtime.openOptionsPage();
});

/**
 * 4. 설정 변경 감지
 * 사용자가 옵션 페이지에서 항목을 추가/삭제하면 메뉴를 즉시 갱신합니다.
 */
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync" && changes.games) {
        updateMenus();
    }
});

/**
 * 5. 메뉴 클릭 이벤트 리스너
 * 클릭한 메뉴의 인덱스에 맞는 URL을 찾아 새 탭을 엽니다.
 */
chrome.contextMenus.onClicked.addListener((info, tab) => {
    const selectionText = (info.selectionText || "").trim();

    chrome.storage.sync.get(["games"], (result) => {
        const games = result.games || [];
        const menuId = info.menuItemId; // 'redeem-0', 'redeem-1' 등의 ID

        // ID에서 인덱스 숫자만 추출
        const index = parseInt(menuId.replace("redeem-", ""));

        if (!isNaN(index) && games[index]) {
            // {n}을 선택한 텍스트로 치환하고 인코딩 처리
            const finalUrl = games[index].url.replace("{n}", encodeURIComponent(selectionText));

            // 새 탭 열기
            chrome.tabs.create({ url: finalUrl });
        }
    });
});